package application;

import javafx.animation.FadeTransition;
import javafx.animation.TranslateTransition;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.util.Duration;

public class DinkartHomePage extends Application {

    @Override
    public void start(Stage stage) {
        // Header
        HBox header = new HBox(20);
        header.setAlignment(Pos.CENTER_LEFT);
        header.setPadding(new Insets(10));
        header.setStyle("-fx-background-color: #2C3E50;");
        
        // Logo
        Image logoImage = new Image(getClass().getResourceAsStream("/logo.jpeg"));
        ImageView logo = new ImageView(logoImage);
        logo.setFitHeight(50);
        logo.setFitWidth(50);
        
        Label companyName = new Label("Dinkart");
        companyName.setStyle("-fx-text-fill: white; -fx-font-size: 24px; -fx-font-weight: bold;");

        // Search Bar
        TextField searchBar = new TextField();
        searchBar.setPromptText("Search for products...");
        searchBar.setPrefWidth(300);

        Button searchButton = new Button("Search");
        searchButton.setStyle("-fx-background-color: #2980B9; -fx-text-fill: white;");

        HBox searchBox = new HBox(10, searchBar, searchButton);
        searchBox.setAlignment(Pos.CENTER);

        Button homeButton = createNavButton("Home");
        Button productsButton = createNavButton("Products");
        Button cartButton = createNavButton("Cart");
        Button accountButton = createNavButton("Account");
        Button signupButton = createNavButton("Sign Up");

        HBox navButtons = new HBox(10, homeButton, productsButton, cartButton, accountButton, signupButton);
        navButtons.setAlignment(Pos.CENTER_RIGHT);

        header.getChildren().addAll(logo, companyName, searchBox, navButtons);

        // Main Content
        VBox mainContent = new VBox(20);
        mainContent.setAlignment(Pos.CENTER);
        mainContent.setPadding(new Insets(20));

        Label welcomeLabel = new Label("Welcome to Dinkart");
        welcomeLabel.setStyle("-fx-font-size: 32px; -fx-font-weight: bold;");
        applyFadeTransition(welcomeLabel, 2000, 0.0, 1.0);

        Label subTitleLabel = new Label("Your one-stop shop for all your needs!");
        subTitleLabel.setStyle("-fx-font-size: 18px;");
        applyFadeTransition(subTitleLabel, 2000, 0.0, 1.0);

        // Categories
        Label categoriesLabel = new Label("Shop by Category");
        categoriesLabel.setStyle("-fx-font-size: 24px; -fx-font-weight: bold;");
        applyFadeTransition(categoriesLabel, 2000, 0.0, 1.0);

        GridPane categoriesGrid = new GridPane();
        categoriesGrid.setAlignment(Pos.CENTER);
        categoriesGrid.setHgap(20);
        categoriesGrid.setVgap(20);

        Button electronicsCategory = createCategoryButton("Electronics");
        Button fashionCategory = createCategoryButton("Fashion");
        Button homeCategory = createCategoryButton("Home & Kitchen");
        Button sportsCategory = createCategoryButton("Sports & Outdoors");

        applyTranslateTransition(electronicsCategory, 1000, -100, 0);
        applyTranslateTransition(fashionCategory, 1200, -100, 0);
        applyTranslateTransition(homeCategory, 1400, -100, 0);
        applyTranslateTransition(sportsCategory, 1600, -100, 0);

        categoriesGrid.add(electronicsCategory, 0, 0);
        categoriesGrid.add(fashionCategory, 1, 0);
        categoriesGrid.add(homeCategory, 0, 1);
        categoriesGrid.add(sportsCategory, 1, 1);

        // Featured Products
        Label featuredLabel = new Label("Featured Products");
        featuredLabel.setStyle("-fx-font-size: 24px; -fx-font-weight: bold;");
        applyFadeTransition(featuredLabel, 2000, 0.0, 1.0);

        HBox featuredProducts = new HBox(15);
        featuredProducts.setAlignment(Pos.CENTER);

        VBox product1 = createProductBox("Product 1", "/product1.jpg");
        VBox product2 = createProductBox("Product 2", "/product2.jpg");
        VBox product3 = createProductBox("Product 3", "/product3.jpg");

        applyTranslateTransition(product1, 1800, 100, 0);
        applyTranslateTransition(product2, 2000, 100, 0);
        applyTranslateTransition(product3, 2200, 100, 0);

        featuredProducts.getChildren().addAll(product1, product2, product3);

        mainContent.getChildren().addAll(welcomeLabel, subTitleLabel, categoriesLabel, categoriesGrid, featuredLabel, featuredProducts);

        // Footer
        HBox footer = new HBox();
        footer.setAlignment(Pos.CENTER);
        footer.setPadding(new Insets(10));
        footer.setStyle("-fx-background-color: #2C3E50;");
        
        Label footerLabel = new Label("© 2024 Dinkart");
        footerLabel.setStyle("-fx-text-fill: white;");
        
        footer.getChildren().add(footerLabel);

        // Background Image
        Image backgroundImage = new Image(getClass().getResourceAsStream("/background.jpeg"));
        BackgroundImage background = new BackgroundImage(backgroundImage, BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT, new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, false, false, true, true));
        mainContent.setBackground(new Background(background));

        // Layout
        BorderPane root = new BorderPane();
        root.setTop(header);
        root.setCenter(mainContent);
        root.setBottom(footer);

        Scene scene = new Scene(root, 1000, 800);
        stage.setTitle("Dinkart Home Page");
        stage.setScene(scene);
        stage.show();
    }

    private Button createNavButton(String text) {
        Button button = new Button(text);
        button.setStyle("-fx-background-color: #2980B9; -fx-text-fill: white;");
        button.setOnAction(event -> {
            // Handle navigation button action
        });
        return button;
    }

    private Button createCategoryButton(String text) {
        Button button = new Button(text);
        button.setPrefSize(200, 100);
        button.setStyle("-fx-background-color: #2C3E50; -fx-text-fill: white; -fx-font-size: 18px;");
        button.setOnAction(event -> {
            // Handle category button action
        });
        return button;
    }

    private VBox createProductBox(String productName, String imagePath) {
        // Product image
        ImageView productImage = new ImageView(new Image(getClass().getResourceAsStream(imagePath)));
        productImage.setFitHeight(150);
        productImage.setFitWidth(150);

        Label productLabel = new Label(productName);
        productLabel.setStyle("-fx-font-size: 16px;");

        Button buyButton = new Button("Buy Now");
        buyButton.setStyle("-fx-background-color: #2980B9; -fx-text-fill: white;");
        buyButton.setOnAction(event -> {
            // Handle buy button action
        });

        VBox productBox = new VBox(10, productImage, productLabel, buyButton);
        productBox.setAlignment(Pos.CENTER);
        return productBox;
    }

    private void applyFadeTransition(Label label, int duration, double fromValue, double toValue) {
        FadeTransition fadeTransition = new FadeTransition(Duration.millis(duration), label);
        fadeTransition.setFromValue(fromValue);
        fadeTransition.setToValue(toValue);
        fadeTransition.play();
    }

    private void applyTranslateTransition(Button button, int duration, double fromX, double toX) {
        TranslateTransition translateTransition = new TranslateTransition(Duration.millis(duration), button);
        translateTransition.setFromX(fromX);
        translateTransition.setToX(toX);
        translateTransition.play();
    }

    private void applyTranslateTransition(VBox vbox, int duration, double fromX, double toX) {
        TranslateTransition translateTransition = new TranslateTransition(Duration.millis(duration), vbox);
        translateTransition.setFromX(fromX);
        translateTransition.setToX(toX);
        translateTransition.play();
    }

    public static void main(String[] args) {
        launch();
    }
}
